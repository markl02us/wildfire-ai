﻿#!/usr/bin/env python3
"""
Wildfire Detection Model Training Script
Trains a CNN model to detect wildfire-related features (smoke, fire, etc.) in images
"""

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
import torchvision.models as models
from PIL import Image
import os
import json
import argparse
import logging
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
import matplotlib.pyplot as plt
from pathlib import Path
import numpy as np

class WildfireDataset(Dataset):
    """Custom dataset for wildfire detection"""
    
    def __init__(self, data_dir, transform=None, train=True):
        self.data_dir = Path(data_dir)
        self.transform = transform
        self.train = train
        
        # Expected directory structure:
        # data_dir/
        #   ├── wildfire/     (images containing fire/smoke)
        #   └── no_wildfire/  (normal landscape images)
        
        self.samples = []
        self.classes = ['no_wildfire', 'wildfire']
        self.class_to_idx = {cls: idx for idx, cls in enumerate(self.classes)}
        
        for class_name in self.classes:
            class_dir = self.data_dir / class_name
            if class_dir.exists():
                for img_path in class_dir.glob('*.jpg'):
                    self.samples.append((img_path, self.class_to_idx[class_name]))
                for img_path in class_dir.glob('*.png'):
                    self.samples.append((img_path, self.class_to_idx[class_name]))
        
        print(f"Found {len(self.samples)} samples in {data_dir}")
        
    def __len__(self):
        return len(self.samples)
    
    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        image = Image.open(img_path).convert('RGB')
        
        if self.transform:
            image = self.transform(image)
            
        return image, label

class WildfireDetectionModel(nn.Module):
    """CNN model for wildfire detection"""
    
    def __init__(self, num_classes=2, backbone='resnet18', pretrained=True):
        super(WildfireDetectionModel, self).__init__()
        
        if backbone == 'resnet18':
            self.backbone = models.resnet18(pretrained=pretrained)
            self.backbone.fc = nn.Linear(self.backbone.fc.in_features, num_classes)
        elif backbone == 'resnet50':
            self.backbone = models.resnet50(pretrained=pretrained)
            self.backbone.fc = nn.Linear(self.backbone.fc.in_features, num_classes)
        elif backbone == 'mobilenet_v2':
            self.backbone = models.mobilenet_v2(pretrained=pretrained)
            self.backbone.classifier[1] = nn.Linear(self.backbone.last_channel, num_classes)
        else:
            raise ValueError(f"Unsupported backbone: {backbone}")
        
    def forward(self, x):
        return self.backbone(x)

class WildfireTrainer:
    def __init__(self, config_path='training_config.json'):
        self.load_config(config_path)
        self.setup_logging()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        print(f"Using device: {self.device}")
        
    def load_config(self, config_path):
        """Load training configuration"""
        default_config = {
            "data": {
                "train_dir": "data/train",
                "val_dir": "data/val",
                "image_size": 224,
                "batch_size": 16
            },
            "model": {
                "backbone": "resnet18",
                "pretrained": True,
                "num_classes": 2
            },
            "training": {
                "epochs": 50,
                "learning_rate": 0.001,
                "weight_decay": 1e-4,
                "patience": 10
            },
            "output": {
                "model_dir": "models",
                "checkpoint_dir": "checkpoints",
                "log_dir": "logs"
            }
        }
        
        try:
            with open(config_path, 'r') as f:
                user_config = json.load(f)
                self.config = {**default_config, **user_config}
        except FileNotFoundError:
            print(f"Config file {config_path} not found. Creating default config.")
            self.config = default_config
            with open(config_path, 'w') as f:
                json.dump(default_config, f, indent=4)
    
    def setup_logging(self):
        """Setup logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('training.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def get_transforms(self, train=True):
        """Get data transforms"""
        image_size = self.config['data']['image_size']
        
        if train:
            return transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.RandomHorizontalFlip(p=0.5),
                transforms.RandomRotation(degrees=15),
                transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                   std=[0.229, 0.224, 0.225])
            ])
        else:
            return transforms.Compose([
                transforms.Resize((image_size, image_size)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                                   std=[0.229, 0.224, 0.225])
            ])
    
    def create_data_loaders(self):
        """Create training and validation data loaders"""
        train_transform = self.get_transforms(train=True)
        val_transform = self.get_transforms(train=False)
        
        train_dataset = WildfireDataset(
            self.config['data']['train_dir'], 
            transform=train_transform, 
            train=True
        )
        
        val_dataset = WildfireDataset(
            self.config['data']['val_dir'], 
            transform=val_transform, 
            train=False
        )
        
        train_loader = DataLoader(
            train_dataset, 
            batch_size=self.config['data']['batch_size'],
            shuffle=True,
            num_workers=4,
            pin_memory=True if torch.cuda.is_available() else False
        )
        
        val_loader = DataLoader(
            val_dataset,
            batch_size=self.config['data']['batch_size'],
            shuffle=False,
            num_workers=4,
            pin_memory=True if torch.cuda.is_available() else False
        )
        
        return train_loader, val_loader
    
    def create_model(self):
        """Create the model"""
        model = WildfireDetectionModel(
            num_classes=self.config['model']['num_classes'],
            backbone=self.config['model']['backbone'],
            pretrained=self.config['model']['pretrained']
        )
        
        return model.to(self.device)
    
    def train_epoch(self, model, train_loader, criterion, optimizer):
        """Train for one epoch"""
        model.train()
        running_loss = 0.0
        predictions = []
        targets = []
        
        for batch_idx, (data, target) in enumerate(train_loader):
            data, target = data.to(self.device), target.to(self.device)
            
            optimizer.zero_grad()
            output = model(data)
            loss = criterion(output, target)
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item()
            pred = output.argmax(dim=1, keepdim=True)
            predictions.extend(pred.cpu().numpy().flatten())
            targets.extend(target.cpu().numpy())
        
        epoch_loss = running_loss / len(train_loader)
        epoch_acc = accuracy_score(targets, predictions)
        
        return epoch_loss, epoch_acc
    
    def validate(self, model, val_loader, criterion):
        """Validate the model"""
        model.eval()
        val_loss = 0.0
        predictions = []
        targets = []
        
        with torch.no_grad():
            for data, target in val_loader:
                data, target = data.to(self.device), target.to(self.device)
                output = model(data)
                val_loss += criterion(output, target).item()
                
                pred = output.argmax(dim=1, keepdim=True)
                predictions.extend(pred.cpu().numpy().flatten())
                targets.extend(target.cpu().numpy())
        
        val_loss /= len(val_loader)
        val_acc = accuracy_score(targets, predictions)
        precision, recall, f1, _ = precision_recall_fscore_support(targets, predictions, average='weighted')
        
        return val_loss, val_acc, precision, recall, f1
    
    def train(self):
        """Main training function"""
        self.logger.info("Starting training...")
        
        # Create output directories
        for dir_key in ['model_dir', 'checkpoint_dir', 'log_dir']:
            Path(self.config['output'][dir_key]).mkdir(exist_ok=True)
        
        # Create data loaders
        train_loader, val_loader = self.create_data_loaders()
        
        # Create model
        model = self.create_model()
        
        # Loss function and optimizer
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(
            model.parameters(), 
            lr=self.config['training']['learning_rate'],
            weight_decay=self.config['training']['weight_decay']
        )
        
        scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode='min', patience=5, factor=0.5, verbose=True
        )
        
        # Training loop
        best_val_acc = 0.0
        patience_counter = 0
        train_losses, val_losses = [], []
        train_accs, val_accs = [], []
        
        for epoch in range(self.config['training']['epochs']):
            # Training
            train_loss, train_acc = self.train_epoch(model, train_loader, criterion, optimizer)
            
            # Validation
            val_loss, val_acc, precision, recall, f1 = self.validate(model, val_loader, criterion)
            
            # Learning rate scheduling
            scheduler.step(val_loss)
            
            # Save metrics
            train_losses.append(train_loss)
            val_losses.append(val_loss)
            train_accs.append(train_acc)
            val_accs.append(val_acc)
            
            # Logging
            self.logger.info(
                f'Epoch {epoch+1}/{self.config["training"]["epochs"]}: '
                f'Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.4f}, '
                f'Val Loss: {val_loss:.4f}, Val Acc: {val_acc:.4f}, '
                f'Precision: {precision:.4f}, Recall: {recall:.4f}, F1: {f1:.4f}'
            )
            
            # Save best model
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                patience_counter = 0
                
                # Save model
                model_path = Path(self.config['output']['model_dir']) / 'wildfire_model.pth'
                torch.save(model, model_path)
                self.logger.info(f'New best model saved: {model_path}')
            else:
                patience_counter += 1
            
            # Early stopping
            if patience_counter >= self.config['training']['patience']:
                self.logger.info(f'Early stopping after {epoch+1} epochs')
                break
        
        # Plot training curves
        self.plot_training_curves(train_losses, val_losses, train_accs, val_accs)
        
        self.logger.info(f'Training completed. Best validation accuracy: {best_val_acc:.4f}')
    
    def plot_training_curves(self, train_losses, val_losses, train_accs, val_accs):
        """Plot training curves"""
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
        
        # Loss curves
        ax1.plot(train_losses, label='Training Loss')
        ax1.plot(val_losses, label='Validation Loss')
        ax1.set_title('Training and Validation Loss')
        ax1.set_xlabel('Epoch')
        ax1.set_ylabel('Loss')
        ax1.legend()
        
        # Accuracy curves
        ax2.plot(train_accs, label='Training Accuracy')
        ax2.plot(val_accs, label='Validation Accuracy')
        ax2.set_title('Training and Validation Accuracy')
        ax2.set_xlabel('Epoch')
        ax2.set_ylabel('Accuracy')
        ax2.legend()
        
        plt.tight_layout()
        plt.savefig(Path(self.config['output']['log_dir']) / 'training_curves.png')
        plt.show()

def main():
    parser = argparse.ArgumentParser(description='Train Wildfire Detection Model')
    parser.add_argument('--config', default='training_config.json', help='Training configuration file')
    args = parser.parse_args()
    
    trainer = WildfireTrainer(args.config)
    trainer.train()

if __name__ == "__main__":
    main()
