﻿#!/bin/bash

# Quick Setup Script for Wildfire Detection System
echo "🔥 Quick Setup for Wildfire Detection System"
echo "============================================"

# Make all scripts executable
chmod +x install_wildfire_detection.sh
chmod +x run_wildfire_detection.sh

echo "✓ Scripts made executable"

# Create basic data structure for training (if needed)
mkdir -p data/{train,val}/{wildfire,no_wildfire}
echo "✓ Training data directories created"

echo ""
echo "Next steps:"
echo "1. Run: ./install_wildfire_detection.sh"
echo "2. Edit config.json with your settings"
echo "3. Add your AI model to models/ directory"
echo "4. Test with: python3 test_system.py"
echo "5. Start with: ./run_wildfire_detection.sh"
echo ""
echo "For training your own model:"
echo "- Add training images to data/train/wildfire/ and data/train/no_wildfire/"
echo "- Add validation images to data/val/wildfire/ and data/val/no_wildfire/"
echo "- Run: python3 model_training.py"
