﻿# 🔥 Wildfire Detection System for NVIDIA Jetson Orin Nano

An AI-powered wildfire detection system that uses computer vision to identify signs of wildfires (smoke, fire, etc.) from camera feeds and automatically sends email alerts.

## ✨ Features

- **Real-time wildfire detection** using AI/ML models
- **Multiple camera support** (CSI, USB, IP cameras)
- **Automatic email alerts** with captured images
- **Memory management** with 60-minute rolling image retention
- **Configurable detection sensitivity** and alert cooldowns
- **Robust logging** and error handling
- **Easy deployment** with systemd service support

## 🎯 Quick Start

### 1. Installation

Run the automated installation script:

```bash
chmod +x install_wildfire_detection.sh
./install_wildfire_detection.sh
```

This will:
- Install all system dependencies
- Set up Python virtual environment
- Install PyTorch and other Python packages
- Create directory structure
- Generate example configuration files

### 2. Configuration

Edit the `config.json` file with your settings:

```json
{
    "camera": {
        "type": "csi",          // csi, usb, or ip
        "device_id": 0,         // for CSI/USB cameras
        "width": 1920,
        "height": 1080
    },
    "email": {
        "sender_email": "your_email@gmail.com",
        "sender_password": "your_app_password",
        "recipient_emails": ["alert@example.com"]
    },
    "model": {
        "path": "models/wildfire_model.pth",
        "confidence_threshold": 0.7
    }
}
```

**Important**: For Gmail, use an [App Password](https://support.google.com/accounts/answer/185833) instead of your regular password.

### 3. Add Your AI Model

Place your trained wildfire detection model at `models/wildfire_model.pth`. The system supports:
- **PyTorch** models (`.pth`, `.pt`)
- **ONNX** models (`.onnx`) 
- **TensorRT** engines (`.trt`)

### 4. Test the System

Run the test script to verify everything is working:

```bash
python3 test_system.py
```

### 5. Start Detection

```bash
# Run once
./run_wildfire_detection.sh

# Or install as system service
sudo cp wildfire-detection.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable wildfire-detection
sudo systemctl start wildfire-detection
```

## 📋 Requirements

### Hardware
- NVIDIA Jetson Orin Nano
- Camera (CSI, USB, or IP camera)
- Internet connection for email alerts

### Software
- JetPack 5.0+ (Ubuntu 20.04)
- Python 3.8+
- PyTorch 1.12+
- OpenCV 4.6+

## 📁 Project Structure

```
wildfire_detection/
├── wildfire_detection.py      # Main application
├── config.json               # Configuration file
├── requirements.txt          # Python dependencies
├── install_wildfire_detection.sh  # Installation script
├── test_system.py           # System test script
├── model_training.py        # Model training script
├── run_wildfire_detection.sh  # Startup script
├── captured_images/         # Saved images (auto-created)
├── models/                  # AI models directory
├── logs/                   # Log files
└── README.md               # This file
```

## ⚙️ Configuration Options

### Camera Settings
```json
"camera": {
    "type": "csi",              // Camera type: csi, usb, ip
    "device_id": 0,             // Device ID for CSI/USB
    "ip_address": "rtsp://...", // IP camera URL
    "width": 1920,              // Image width
    "height": 1080,             // Image height
    "fps": 30                   // Frame rate
}
```

### Detection Settings
```json
"model": {
    "path": "models/wildfire_model.pth",  // Model file path
    "type": "pytorch",                    // pytorch, onnx, tensorrt
    "confidence_threshold": 0.7,          // Detection threshold (0.0-1.0)
    "input_size": [224, 224]             // Model input dimensions
}
```

### Alert Settings
```json
"email": {
    "smtp_server": "smtp.gmail.com",      // SMTP server
    "smtp_port": 587,                     // SMTP port
    "sender_email": "alerts@example.com", // Sender email
    "sender_password": "app_password",    // App password
    "recipient_emails": ["user@example.com"], // Alert recipients
    "subject": "🔥 Wildfire Alert"        // Email subject
}
```

### Memory Management
```json
"memory_management": {
    "retention_minutes": 60,              // Keep images for 60 minutes
    "cleanup_interval_minutes": 5        // Clean up every 5 minutes
}
```

## 🤖 Training Your Own Model

Use the provided training script to create a custom wildfire detection model:

```bash
# Prepare your dataset in this structure:
# data/
#   ├── train/
#   │   ├── wildfire/     (images with fire/smoke)
#   │   └── no_wildfire/  (normal images)
#   └── val/
#       ├── wildfire/
#       └── no_wildfire/

# Train the model
python3 model_training.py --config training_config.json
```

The training script will:
- Use transfer learning with pre-trained models
- Apply data augmentation
- Save the best model automatically
- Generate training curves

## 🔧 Troubleshooting

### Camera Issues
```bash
# Test CSI camera
gst-launch-1.0 nvarguscamerasrc ! nvoverlaysink

# Test USB camera
v4l2-ctl --list-devices
```

### Memory Issues
```bash
# Monitor memory usage
htop
nvidia-smi

# Clear cache
sudo sh -c 'echo 3 > /proc/sys/vm/drop_caches'
```

### Model Issues
```bash
# Test model loading
python3 -c "import torch; model = torch.load('models/wildfire_model.pth'); print('Model loaded successfully')"
```

### Email Issues
- Use App Password for Gmail (not regular password)
- Check firewall settings for SMTP ports
- Verify email configuration in `config.json`

## 📊 Monitoring and Logs

### Log Files
- **System logs**: `logs/wildfire_detection.log`
- **Training logs**: `logs/training.log`

### System Service Status
```bash
# Check service status
sudo systemctl status wildfire-detection

# View live logs
journalctl -u wildfire-detection -f

# Restart service
sudo systemctl restart wildfire-detection
```

### Performance Monitoring
```bash
# Monitor GPU usage
nvidia-smi -l 1

# Monitor system resources
htop
```

## 🚀 Advanced Features

### Custom Alert Logic
Modify the `send_alert()` method in `wildfire_detection.py` to:
- Add SMS alerts
- Integrate with IoT platforms
- Send alerts to mobile apps
- Trigger automated responses

### Multi-Camera Support
The system can be extended to support multiple cameras by:
- Creating multiple camera instances
- Processing streams in parallel
- Aggregating detection results

### Cloud Integration
- Upload alerts to cloud storage
- Use cloud-based AI models
- Remote monitoring and control

## 📜 License

This project is provided as-is for educational and research purposes. Please ensure compliance with local regulations regarding wildfire monitoring and alert systems.

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## 🆘 Support

For issues and questions:
1. Check the troubleshooting section
2. Review log files for error details
3. Test individual components with `test_system.py`
4. Ensure all dependencies are properly installed

## 📝 Notes

- **Safety First**: This system is for early warning only. Always follow official evacuation procedures and emergency protocols.
- **Model Accuracy**: Detection accuracy depends on your training data and model quality. Regularly update and improve your model.
- **Power Management**: Consider UPS backup power for continuous monitoring.
- **Network Redundancy**: Use multiple network connections for critical installations.

---

**Happy wildfire detecting! Stay safe! 🔥🚒**
