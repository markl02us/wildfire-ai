﻿#!/bin/bash

# Wildfire Detection System Installation Script for NVIDIA Jetson Orin Nano
# This script sets up the complete environment for the wildfire detection system

set -e

echo "🔥 Wildfire Detection System Installation Script"
echo "================================================"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running on Jetson
check_jetson() {
    if [ ! -f /etc/nv_tegra_release ]; then
        print_warning "This doesn't appear to be a NVIDIA Jetson device."
        read -p "Continue anyway? (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    else
        print_status "Detected NVIDIA Jetson device"
        cat /etc/nv_tegra_release
    fi
}

# Update system packages
update_system() {
    print_status "Updating system packages..."
    sudo apt update
    sudo apt upgrade -y
}

# Install system dependencies
install_system_deps() {
    print_status "Installing system dependencies..."
    
    sudo apt install -y \
        python3-pip \
        python3-dev \
        python3-venv \
        build-essential \
        cmake \
        pkg-config \
        libjpeg-dev \
        libpng-dev \
        libtiff-dev \
        libavcodec-dev \
        libavformat-dev \
        libswscale-dev \
        libv4l-dev \
        libxvidcore-dev \
        libx264-dev \
        libgtk-3-dev \
        libatlas-base-dev \
        gfortran \
        libhdf5-serial-dev \
        libhdf5-dev \
        libhdf5-103 \
        libqt5gui5 \
        libqt5webkit5 \
        libqt5test5 \
        python3-pyqt5 \
        git \
        wget \
        curl \
        unzip
}

# Create project directory and virtual environment
setup_project() {
    print_status "Setting up project directory..."
    
    PROJECT_DIR="$HOME/wildfire_detection"
    
    # Create project directory
    mkdir -p "$PROJECT_DIR"
    cd "$PROJECT_DIR"
    
    # Create virtual environment
    python3 -m venv venv
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip setuptools wheel
    
    print_status "Project directory created at: $PROJECT_DIR"
}

# Install PyTorch for Jetson
install_pytorch() {
    print_status "Installing PyTorch for Jetson..."
    
    # PyTorch wheel for Jetson (adjust version as needed)
    PYTORCH_WHL="https://developer.download.nvidia.com/compute/redist/jp/v50/pytorch/torch-1.12.0a0+2c916ef.nv22.3-cp38-cp38-linux_aarch64.whl"
    
    pip install numpy
    pip install "$PYTORCH_WHL"
    pip install torchvision
}

# Install OpenCV
install_opencv() {
    print_status "Installing OpenCV..."
    
    # Install OpenCV with GStreamer support
    pip install opencv-python
    
    # Verify GStreamer support
    python3 -c "import cv2; print('OpenCV version:', cv2.__version__)"
}

# Install Python dependencies
install_python_deps() {
    print_status "Installing Python dependencies..."
    
    # Install from requirements file if it exists, otherwise install manually
    if [ -f requirements.txt ]; then
        pip install -r requirements.txt
    else
        pip install \
            numpy \
            Pillow \
            psutil \
            GPUtil
    fi
}

# Create directory structure
create_directories() {
    print_status "Creating directory structure..."
    
    mkdir -p captured_images
    mkdir -p models
    mkdir -p logs
    mkdir -p config
}

# Create example model file
create_example_model() {
    print_status "Creating example model file..."
    
    cat > create_example_model.py << 'EOF'
import torch
import torch.nn as nn
import torchvision.models as models

class WildfireDetectionModel(nn.Module):
    def __init__(self, num_classes=2):
        super(WildfireDetectionModel, self).__init__()
        # Use a pre-trained ResNet as backbone
        self.backbone = models.resnet18(pretrained=True)
        self.backbone.fc = nn.Linear(self.backbone.fc.in_features, num_classes)
        
    def forward(self, x):
        return self.backbone(x)

# Create and save example model
print("Creating example wildfire detection model...")
model = WildfireDetectionModel()

# Save the model
torch.save(model, 'models/wildfire_model.pth')
print("Example model saved to models/wildfire_model.pth")
print("Note: This is a basic model. Replace with your trained model for actual detection.")
EOF

    python3 create_example_model.py
    rm create_example_model.py
}

# Create systemd service file
create_service() {
    print_status "Creating systemd service file..."
    
    SERVICE_FILE="/tmp/wildfire-detection.service"
    
    cat > "$SERVICE_FILE" << EOF
[Unit]
Description=Wildfire Detection System
After=network.target

[Service]
Type=simple
User=$USER
WorkingDirectory=$PROJECT_DIR
Environment=PATH=$PROJECT_DIR/venv/bin
ExecStart=$PROJECT_DIR/venv/bin/python wildfire_detection.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

    print_status "Service file created. To install as system service:"
    echo "  sudo cp $SERVICE_FILE /etc/systemd/system/"
    echo "  sudo systemctl daemon-reload"
    echo "  sudo systemctl enable wildfire-detection"
    echo "  sudo systemctl start wildfire-detection"
}

# Create startup script
create_startup_script() {
    print_status "Creating startup script..."
    
    cat > run_wildfire_detection.sh << 'EOF'
#!/bin/bash

# Wildfire Detection System Startup Script
cd "$(dirname "$0")"

# Activate virtual environment
source venv/bin/activate

# Check if config exists
if [ ! -f config.json ]; then
    echo "Config file not found. Please create config.json first."
    echo "See config_template.json for reference."
    exit 1
fi

# Run the detection system
python wildfire_detection.py --config config.json
EOF

    chmod +x run_wildfire_detection.sh
}

# Main installation function
main() {
    echo "Starting installation process..."
    echo "This will install the wildfire detection system on your Jetson Orin Nano."
    echo
    
    read -p "Do you want to continue? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
    
    check_jetson
    update_system
    install_system_deps
    setup_project
    
    # Source the virtual environment for the rest of the installation
    source venv/bin/activate
    
    install_pytorch
    install_opencv
    install_python_deps
    create_directories
    create_example_model
    create_service
    create_startup_script
    
    print_status "Installation completed successfully!"
    echo
    echo "Next steps:"
    echo "1. Copy your trained AI model to models/wildfire_model.pth"
    echo "2. Edit config.json with your camera and email settings"
    echo "3. Test the system: ./run_wildfire_detection.sh"
    echo "4. Install as service (optional): see instructions above"
    echo
    echo "Project location: $PROJECT_DIR"
    
}

# Run main function
main "$@"
