﻿#!/usr/bin/env python3
"""
Wildfire Detection System for NVIDIA Jetson Orin Nano
Captures images, processes them with AI model, and sends email alerts
"""

import cv2
import numpy as np
import torch
import torchvision.transforms as transforms
from datetime import datetime, timedelta
import os
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import time
import logging
import threading
from queue import Queue
import pickle
from pathlib import Path
import argparse

class WildfireDetectionSystem:
    def __init__(self, config_path="config.json"):
        """Initialize the wildfire detection system"""
        self.load_config(config_path)
        self.setup_logging()
        
        # Image storage for comparison
        self.image_history = []
        self.image_queue = Queue()
        self.detection_history = []
        
        # Alert management
        self.last_alert_time = None
        self.alert_cooldown = timedelta(minutes=self.config['alert_cooldown_minutes'])
        
        # Initialize components
        self.camera = None
        self.model = None
        self.running = False
        
    def load_config(self, config_path):
        """Load configuration from JSON file"""
        default_config = {
            "camera": {
                "type": "csi",  # csi, usb, or ip
                "device_id": 0,
                "ip_address": "",
                "width": 1920,
                "height": 1080,
                "fps": 30
            },
            "capture": {
                "interval_seconds": 30,
                "save_images": True,
                "image_dir": "captured_images"
            },
            "model": {
                "path": "wildfire_model.pth",
                "type": "pytorch",  # pytorch, onnx, tensorrt
                "confidence_threshold": 0.7,
                "input_size": [224, 224]
            },
            "email": {
                "smtp_server": "smtp.gmail.com",
                "smtp_port": 587,
                "sender_email": "",
                "sender_password": "",
                "recipient_emails": [],
                "subject": "Wildfire Alert - Detection System"
            },
            "memory_management": {
                "retention_minutes": 60,
                "cleanup_interval_minutes": 5
            },
            "alert_cooldown_minutes": 10,
            "logging_level": "INFO"
        }
        
        try:
            with open(config_path, 'r') as f:
                user_config = json.load(f)
                # Merge with defaults
                self.config = {**default_config, **user_config}
        except FileNotFoundError:
            print(f"Config file {config_path} not found. Creating default config.")
            self.config = default_config
            with open(config_path, 'w') as f:
                json.dump(default_config, f, indent=4)
    
    def setup_logging(self):
        """Setup logging configuration"""
        log_level = getattr(logging, self.config['logging_level'].upper())
        logging.basicConfig(
            level=log_level,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('wildfire_detection.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def initialize_camera(self):
        """Initialize camera based on configuration"""
        camera_config = self.config['camera']
        
        try:
            if camera_config['type'] == 'csi':
                # CSI camera using GStreamer pipeline
                pipeline = (
                    f"nvarguscamerasrc sensor-id={camera_config['device_id']} ! "
                    f"video/x-raw(memory:NVMM), "
                    f"width={camera_config['width']}, height={camera_config['height']}, "
                    f"format=NV12, framerate={camera_config['fps']}/1 ! "
                    f"nvvidconv flip-method=0 ! "
                    f"video/x-raw, format=BGRx ! "
                    f"videoconvert ! "
                    f"video/x-raw, format=BGR ! appsink"
                )
                self.camera = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
                
            elif camera_config['type'] == 'usb':
                self.camera = cv2.VideoCapture(camera_config['device_id'])
                self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, camera_config['width'])
                self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, camera_config['height'])
                self.camera.set(cv2.CAP_PROP_FPS, camera_config['fps'])
                
            elif camera_config['type'] == 'ip':
                self.camera = cv2.VideoCapture(camera_config['ip_address'])
            
            if not self.camera.isOpened():
                raise Exception("Failed to open camera")
                
            self.logger.info(f"Camera initialized: {camera_config['type']}")
            return True
            
        except Exception as e:
            self.logger.error(f"Camera initialization failed: {e}")
            return False
    
    def load_ai_model(self):
        """Load the AI model for wildfire detection"""
        model_config = self.config['model']
        model_path = model_config['path']
        
        try:
            if model_config['type'] == 'pytorch':
                self.model = torch.load(model_path, map_location='cuda' if torch.cuda.is_available() else 'cpu')
                self.model.eval()
                
            elif model_config['type'] == 'onnx':
                import onnxruntime as ort
                self.model = ort.InferenceSession(model_path)
                
            elif model_config['type'] == 'tensorrt':
                # TensorRT implementation would go here
                import tensorrt as trt
                # TensorRT loading code...
                pass
            
            self.logger.info(f"AI model loaded: {model_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Model loading failed: {e}")
            return False
    
    def preprocess_image(self, image):
        """Preprocess image for AI model"""
        input_size = self.config['model']['input_size']
        
        # Resize image
        image_resized = cv2.resize(image, tuple(input_size))
        
        # Convert to RGB if needed
        if len(image_resized.shape) == 3:
            image_rgb = cv2.cvtColor(image_resized, cv2.COLOR_BGR2RGB)
        else:
            image_rgb = image_resized
        
        # Normalize and convert to tensor
        transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.485, 0.456, 0.406], 
                               std=[0.229, 0.224, 0.225])
        ])
        
        tensor = transform(image_rgb).unsqueeze(0)
        
        if torch.cuda.is_available():
            tensor = tensor.cuda()
            
        return tensor
    
    def detect_wildfire(self, image):
        """Run wildfire detection on image"""
        try:
            preprocessed = self.preprocess_image(image)
            
            with torch.no_grad():
                if self.config['model']['type'] == 'pytorch':
                    output = self.model(preprocessed)
                    # Assuming binary classification (wildfire/no wildfire)
                    probability = torch.sigmoid(output).item()
                    
                elif self.config['model']['type'] == 'onnx':
                    input_name = self.model.get_inputs()[0].name
                    output = self.model.run(None, {input_name: preprocessed.cpu().numpy()})
                    probability = output[0][0][1]  # Assuming softmax output
            
            confidence = probability
            is_wildfire = confidence > self.config['model']['confidence_threshold']
            
            return is_wildfire, confidence
            
        except Exception as e:
            self.logger.error(f"Detection failed: {e}")
            return False, 0.0
    
    def capture_and_process(self):
        """Capture image and process for wildfire detection"""
        ret, frame = self.camera.read()
        if not ret:
            self.logger.warning("Failed to capture image")
            return False
        
        timestamp = datetime.now()
        
        # Save image if configured
        if self.config['capture']['save_images']:
            image_dir = Path(self.config['capture']['image_dir'])
            image_dir.mkdir(exist_ok=True)
            filename = f"capture_{timestamp.strftime('%Y%m%d_%H%M%S')}.jpg"
            cv2.imwrite(str(image_dir / filename), frame)
        
        # Run detection
        is_wildfire, confidence = self.detect_wildfire(frame)
        
        # Store in history
        detection_data = {
            'timestamp': timestamp,
            'is_wildfire': is_wildfire,
            'confidence': confidence,
            'image_path': str(image_dir / filename) if self.config['capture']['save_images'] else None
        }
        
        self.detection_history.append(detection_data)
        self.image_history.append({
            'timestamp': timestamp,
            'image': frame.copy(),
            'detection': detection_data
        })
        
        # Send alert if wildfire detected
        if is_wildfire:
            self.send_alert(detection_data, frame)
        
        self.logger.info(f"Processed image: wildfire={is_wildfire}, confidence={confidence:.3f}")
        return True
    
    def send_alert(self, detection_data, image):
        """Send email alert for wildfire detection"""
        # Check cooldown period
        current_time = detection_data['timestamp']
        if (self.last_alert_time and 
            current_time - self.last_alert_time < self.alert_cooldown):
            self.logger.info("Alert skipped due to cooldown period")
            return
        
        try:
            email_config = self.config['email']
            
            # Create message
            msg = MIMEMultipart()
            msg['From'] = email_config['sender_email']
            msg['To'] = ', '.join(email_config['recipient_emails'])
            msg['Subject'] = email_config['subject']
            
            # Email body
            body = f"""
Wildfire Detection Alert

Timestamp: {detection_data['timestamp'].strftime('%Y-%m-%d %H:%M:%S')}
Confidence: {detection_data['confidence']:.2%}
Location: Jetson Orin Nano Detection System

Please verify the detection and take appropriate action if necessary.
            """
            
            msg.attach(MIMEText(body, 'plain'))
            
            # Attach image
            _, buffer = cv2.imencode('.jpg', image)
            img_attachment = MIMEImage(buffer.tobytes())
            img_attachment.add_header('Content-Disposition', 
                                    f'attachment; filename=wildfire_detection_{detection_data["timestamp"].strftime("%Y%m%d_%H%M%S")}.jpg')
            msg.attach(img_attachment)
            
            # Send email
            server = smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'])
            server.starttls()
            server.login(email_config['sender_email'], email_config['sender_password'])
            
            for recipient in email_config['recipient_emails']:
                server.sendmail(email_config['sender_email'], recipient, msg.as_string())
            
            server.quit()
            
            self.last_alert_time = current_time
            self.logger.info(f"Alert sent to {len(email_config['recipient_emails'])} recipients")
            
        except Exception as e:
            self.logger.error(f"Failed to send alert: {e}")
    
    def cleanup_old_data(self):
        """Clean up old images and detection data"""
        cutoff_time = datetime.now() - timedelta(minutes=self.config['memory_management']['retention_minutes'])
        
        # Clean detection history
        self.detection_history = [d for d in self.detection_history 
                                 if d['timestamp'] > cutoff_time]
        
        # Clean image history
        self.image_history = [img for img in self.image_history 
                             if img['timestamp'] > cutoff_time]
        
        # Clean saved images
        if self.config['capture']['save_images']:
            image_dir = Path(self.config['capture']['image_dir'])
            if image_dir.exists():
                for image_file in image_dir.glob("*.jpg"):
                    try:
                        # Extract timestamp from filename
                        timestamp_str = image_file.stem.split('_', 1)[1]
                        file_time = datetime.strptime(timestamp_str, '%Y%m%d_%H%M%S')
                        if file_time < cutoff_time:
                            image_file.unlink()
                    except:
                        continue
        
        self.logger.info(f"Cleaned up data older than {self.config['memory_management']['retention_minutes']} minutes")
    
    def cleanup_worker(self):
        """Worker thread for periodic cleanup"""
        cleanup_interval = self.config['memory_management']['cleanup_interval_minutes'] * 60
        
        while self.running:
            time.sleep(cleanup_interval)
            if self.running:
                self.cleanup_old_data()
    
    def run(self):
        """Main execution loop"""
        self.logger.info("Starting Wildfire Detection System")
        
        # Initialize components
        if not self.initialize_camera():
            return False
        
        if not self.load_ai_model():
            return False
        
        self.running = True
        
        # Start cleanup worker thread
        cleanup_thread = threading.Thread(target=self.cleanup_worker, daemon=True)
        cleanup_thread.start()
        
        # Main processing loop
        capture_interval = self.config['capture']['interval_seconds']
        
        try:
            while self.running:
                start_time = time.time()
                
                self.capture_and_process()
                
                # Sleep for remaining interval time
                elapsed = time.time() - start_time
                sleep_time = max(0, capture_interval - elapsed)
                time.sleep(sleep_time)
                
        except KeyboardInterrupt:
            self.logger.info("Shutdown requested by user")
        except Exception as e:
            self.logger.error(f"Unexpected error: {e}")
        finally:
            self.shutdown()
    
    def shutdown(self):
        """Clean shutdown of the system"""
        self.logger.info("Shutting down system...")
        self.running = False
        
        if self.camera:
            self.camera.release()
        
        cv2.destroyAllWindows()
        self.logger.info("System shutdown complete")

def main():
    parser = argparse.ArgumentParser(description='Wildfire Detection System')
    parser.add_argument('--config', default='config.json', help='Configuration file path')
    args = parser.parse_args()
    
    system = WildfireDetectionSystem(args.config)
    system.run()

if __name__ == "__main__":
    main()
