﻿#!/usr/bin/env python3
"""
Wildfire Detection System Test Script
Tests all components of the system without requiring a trained model
"""

import cv2
import torch
import numpy as np
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
import logging
import sys
from datetime import datetime

class SystemTester:
    def __init__(self):
        self.setup_logging()
        self.test_results = {}
        
    def setup_logging(self):
        """Setup logging"""
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[logging.StreamHandler()]
        )
        self.logger = logging.getLogger(__name__)
    
    def test_config_file(self):
        """Test configuration file loading"""
        self.logger.info("Testing configuration file...")
        
        try:
            if not Path('config.json').exists():
                self.logger.warning("config.json not found. Creating template...")
                # Create minimal config for testing
                config = {
                    "camera": {"type": "csi", "device_id": 0},
                    "email": {"sender_email": "", "recipient_emails": []},
                    "model": {"path": "test_model.pth"}
                }
                with open('config.json', 'w') as f:
                    json.dump(config, f, indent=4)
                self.test_results['config'] = 'CREATED'
            else:
                with open('config.json', 'r') as f:
                    config = json.load(f)
                self.test_results['config'] = 'PASS'
            
            self.logger.info("✓ Configuration file test passed")
            return True
            
        except Exception as e:
            self.logger.error(f"✗ Configuration test failed: {e}")
            self.test_results['config'] = 'FAIL'
            return False
    
    def test_pytorch(self):
        """Test PyTorch installation and CUDA availability"""
        self.logger.info("Testing PyTorch installation...")
        
        try:
            import torch
            self.logger.info(f"PyTorch version: {torch.__version__}")
            
            # Test CUDA
            if torch.cuda.is_available():
                device_count = torch.cuda.device_count()
                current_device = torch.cuda.current_device()
                device_name = torch.cuda.get_device_name(current_device)
                self.logger.info(f"CUDA available: {device_count} device(s)")
                self.logger.info(f"Current device: {device_name}")
                
                # Test tensor operations on GPU
                x = torch.randn(10, 10).cuda()
                y = x @ x.T
                self.logger.info("✓ CUDA tensor operations working")
            else:
                self.logger.warning("CUDA not available, using CPU")
            
            self.test_results['pytorch'] = 'PASS'
            self.logger.info("✓ PyTorch test passed")
            return True
            
        except Exception as e:
            self.logger.error(f"✗ PyTorch test failed: {e}")
            self.test_results['pytorch'] = 'FAIL'
            return False
    
    def test_opencv(self):
        """Test OpenCV installation and camera support"""
        self.logger.info("Testing OpenCV installation...")
        
        try:
            import cv2
            self.logger.info(f"OpenCV version: {cv2.__version__}")
            
            # Test basic image operations
            test_img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
            resized = cv2.resize(test_img, (224, 224))
            gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
            
            self.logger.info("✓ Basic OpenCV operations working")
            
            # Test GStreamer support (important for Jetson CSI cameras)
            build_info = cv2.getBuildInformation()
            if 'GStreamer' in build_info and 'YES' in build_info:
                self.logger.info("✓ GStreamer support detected")
            else:
                self.logger.warning("GStreamer support not detected")
            
            self.test_results['opencv'] = 'PASS'
            self.logger.info("✓ OpenCV test passed")
            return True
            
        except Exception as e:
            self.logger.error(f"✗ OpenCV test failed: {e}")
            self.test_results['opencv'] = 'FAIL'
            return False
    
    def test_camera_access(self):
        """Test camera access"""
        self.logger.info("Testing camera access...")
        
        try:
            # Try different camera interfaces
            camera_found = False
            
            # Test CSI camera (common on Jetson)
            try:
                pipeline = (
                    "nvarguscamerasrc sensor-id=0 ! "
                    "video/x-raw(memory:NVMM), width=640, height=480, "
                    "format=NV12, framerate=30/1 ! "
                    "nvvidconv flip-method=0 ! "
                    "video/x-raw, format=BGRx ! "
                    "videoconvert ! "
                    "video/x-raw, format=BGR ! appsink"
                )
                cap = cv2.VideoCapture(pipeline, cv2.CAP_GSTREAMER)
                if cap.isOpened():
                    ret, frame = cap.read()
                    if ret:
                        self.logger.info("✓ CSI camera working")
                        camera_found = True
                    cap.release()
            except:
                pass
            
            # Test USB camera
            if not camera_found:
                try:
                    cap = cv2.VideoCapture(0)
                    if cap.isOpened():
                        ret, frame = cap.read()
                        if ret:
                            self.logger.info("✓ USB camera working")
                            camera_found = True
                        cap.release()
                except:
                    pass
            
            if camera_found:
                self.test_results['camera'] = 'PASS'
                self.logger.info("✓ Camera test passed")
                return True
            else:
                self.logger.warning("No camera detected (this is OK if no camera is connected)")
                self.test_results['camera'] = 'NO_CAMERA'
                return True
                
        except Exception as e:
            self.logger.error(f"✗ Camera test failed: {e}")
            self.test_results['camera'] = 'FAIL'
            return False
    
    def test_email_config(self):
        """Test email configuration (without sending)"""
        self.logger.info("Testing email configuration...")
        
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
            
            email_config = config.get('email', {})
            
            # Check required fields
            required_fields = ['sender_email', 'sender_password', 'recipient_emails']
            missing_fields = []
            
            for field in required_fields:
                if not email_config.get(field):
                    missing_fields.append(field)
            
            if missing_fields:
                self.logger.warning(f"Email config incomplete. Missing: {missing_fields}")
                self.test_results['email'] = 'INCOMPLETE'
            else:
                # Test SMTP connection (without authentication)
                try:
                    import smtplib
                    server = smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'])
                    server.quit()
                    self.logger.info("✓ SMTP server reachable")
                    self.test_results['email'] = 'PASS'
                except:
                    self.logger.warning("SMTP server not reachable (check network)")
                    self.test_results['email'] = 'NETWORK_ISSUE'
            
            self.logger.info("✓ Email configuration test completed")
            return True
            
        except Exception as e:
            self.logger.error(f"✗ Email test failed: {e}")
            self.test_results['email'] = 'FAIL'
            return False
    
    def test_directory_structure(self):
        """Test directory structure"""
        self.logger.info("Testing directory structure...")
        
        try:
            required_dirs = ['captured_images', 'models', 'logs']
            
            for dir_name in required_dirs:
                dir_path = Path(dir_name)
                if not dir_path.exists():
                    dir_path.mkdir(exist_ok=True)
                    self.logger.info(f"Created directory: {dir_name}")
                
                # Test write permissions
                test_file = dir_path / 'test_write.tmp'
                test_file.write_text('test')
                test_file.unlink()
            
            self.test_results['directories'] = 'PASS'
            self.logger.info("✓ Directory structure test passed")
            return True
            
        except Exception as e:
            self.logger.error(f"✗ Directory test failed: {e}")
            self.test_results['directories'] = 'FAIL'
            return False
    
    def create_dummy_model(self):
        """Create a dummy model for testing"""
        self.logger.info("Creating dummy model for testing...")
        
        try:
            import torch
            import torch.nn as nn
            
            class DummyModel(nn.Module):
                def __init__(self):
                    super(DummyModel, self).__init__()
                    self.conv1 = nn.Conv2d(3, 64, kernel_size=3, padding=1)
                    self.pool = nn.AdaptiveAvgPool2d((1, 1))
                    self.fc = nn.Linear(64, 2)  # Binary classification
                    
                def forward(self, x):
                    x = torch.relu(self.conv1(x))
                    x = self.pool(x)
                    x = x.view(x.size(0), -1)
                    x = self.fc(x)
                    return x
            
            dummy_model = DummyModel()
            torch.save(dummy_model, 'models/test_model.pth')
            
            # Test loading
            loaded_model = torch.load('models/test_model.pth', map_location='cpu')
            loaded_model.eval()
            
            # Test inference
            dummy_input = torch.randn(1, 3, 224, 224)
            with torch.no_grad():
                output = loaded_model(dummy_input)
            
            self.logger.info("✓ Dummy model created and tested")
            self.test_results['dummy_model'] = 'PASS'
            return True
            
        except Exception as e:
            self.logger.error(f"✗ Dummy model test failed: {e}")
            self.test_results['dummy_model'] = 'FAIL'
            return False
    
    def test_memory_usage(self):
        """Test memory usage and monitoring"""
        self.logger.info("Testing memory usage...")
        
        try:
            import psutil
            
            # Get memory info
            memory = psutil.virtual_memory()
            self.logger.info(f"Total memory: {memory.total / (1024**3):.2f} GB")
            self.logger.info(f"Available memory: {memory.available / (1024**3):.2f} GB")
            self.logger.info(f"Memory usage: {memory.percent}%")
            
            if memory.available < 1024**3:  # Less than 1GB available
                self.logger.warning("Low memory available")
            
            # Test GPU memory if available
            if torch.cuda.is_available():
                gpu_memory = torch.cuda.get_device_properties(0).total_memory
                gpu_allocated = torch.cuda.memory_allocated(0)
                self.logger.info(f"GPU memory: {gpu_memory / (1024**3):.2f} GB total")
                self.logger.info(f"GPU allocated: {gpu_allocated / (1024**3):.2f} GB")
            
            self.test_results['memory'] = 'PASS'
            self.logger.info("✓ Memory test passed")
            return True
            
        except Exception as e:
            self.logger.error(f"✗ Memory test failed: {e}")
            self.test_results['memory'] = 'FAIL'
            return False
    
    def run_all_tests(self):
        """Run all system tests"""
        self.logger.info("="*50)
        self.logger.info("Starting Wildfire Detection System Tests")
        self.logger.info("="*50)
        
        tests = [
            ('Configuration', self.test_config_file),
            ('PyTorch', self.test_pytorch),
            ('OpenCV', self.test_opencv),
            ('Camera Access', self.test_camera_access),
            ('Email Config', self.test_email_config),
            ('Directory Structure', self.test_directory_structure),
            ('Dummy Model', self.create_dummy_model),
            ('Memory Usage', self.test_memory_usage),
        ]
        
        results = []
        for test_name, test_func in tests:
            self.logger.info(f"\n{'='*20} {test_name} {'='*20}")
            success = test_func()
            results.append((test_name, success))
        
        # Print summary
        self.logger.info("\n" + "="*50)
        self.logger.info("TEST SUMMARY")
        self.logger.info("="*50)
        
        for test_name, success in results:
            status = self.test_results.get(test_name.lower().replace(' ', '_'), 'UNKNOWN')
            self.logger.info(f"{test_name:20} : {status}")
        
        passed = sum(1 for _, success in results if success)
        total = len(results)
        
        self.logger.info(f"\nTests passed: {passed}/{total}")
        
        if passed == total:
            self.logger.info("🎉 All tests passed! System is ready.")
        else:
            self.logger.warning("⚠️ Some tests failed. Please check the issues above.")
        
        return passed == total

def main():
    tester = SystemTester()
    success = tester.run_all_tests()
    
    if not success:
        sys.exit(1)

if __name__ == "__main__":
    main()
