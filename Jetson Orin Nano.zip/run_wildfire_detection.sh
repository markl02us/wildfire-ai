﻿#!/bin/bash

# Wildfire Detection System Startup Script
cd "$(dirname "$0")"

echo "🔥 Starting Wildfire Detection System"
echo "====================================="

# Check if virtual environment exists
if [ ! -d "venv" ]; then
    echo "Virtual environment not found. Please run the installation script first."
    exit 1
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate

# Check if config exists
if [ ! -f config.json ]; then
    echo "Config file not found. Please create config.json first."
    echo "See the provided template for reference."
    exit 1
fi

# Check if model exists
MODEL_PATH=$(python3 -c "import json; config=json.load(open('config.json')); print(config['model']['path'])" 2>/dev/null)
if [ ! -f "$MODEL_PATH" ]; then
    echo "AI model not found at: $MODEL_PATH"
    echo "Please ensure your trained model is available, or use the test model."
    exit 1
fi

echo "Configuration verified. Starting detection system..."
echo "Press Ctrl+C to stop the system."
echo ""

# Run the detection system
python wildfire_detection.py --config config.json
