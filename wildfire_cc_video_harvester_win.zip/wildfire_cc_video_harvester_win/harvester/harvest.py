import os, csv, re, time, json, math, sys, hashlib
from pathlib import Path
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlencode, quote_plus

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output"
OUT.mkdir(parents=True, exist_ok=True)
CSV_PATH = OUT / "wildfire_videos.csv"
M3U_PATH = OUT / "wildfire_videos.m3u"
CONFIG = ROOT / "harvester" / "config.yaml"

def load_config():
    import yaml
    with open(CONFIG, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def row_hash(row):
    m = hashlib.sha256()
    m.update(("|".join([str(row.get(k,"")) for k in ["mp4_url","page_url","source"]])).encode("utf-8"))
    return m.hexdigest()

def dedupe_rows(rows, existing):
    seen = set(x.get("hash") for x in existing)
    out = []
    for r in rows:
        h = row_hash(r)
        if h not in seen:
            r["hash"] = h
            out.append(r)
            seen.add(h)
    return out

def read_existing():
    if not CSV_PATH.exists():
        return []
    out = []
    with open(CSV_PATH, "r", newline="", encoding="utf-8") as f:
        rdr = csv.DictReader(f)
        for r in rdr:
            out.append(r)
    return out

def write_rows(rows):
    header = ["source","title","mp4_url","page_url","license","duration","resolution","notes","hash"]
    write_header = not CSV_PATH.exists()
    with open(CSV_PATH, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=header)
        if write_header:
            w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k,"") for k in header})
    # also write an .m3u with direct mp4s only
    with open(M3U_PATH, "a", encoding="utf-8") as g:
        for r in rows:
            if r.get("mp4_url","").lower().endswith(".mp4"):
                g.write(r["mp4_url"] + "\n")

# -------- Internet Archive --------
def harvest_archive(cfg, target):
    collected = []
    q_terms = cfg.get("queries",["wildfire"])
    license_allow = [s.lower() for s in cfg.get("license_allow",[])]
    rows_per_page = 1000
    for q in q_terms:
        page = 1
        while len(collected) < target:
            params = {
                "q": f'({q}) AND mediatype:movies',
                "output": "json",
                "rows": rows_per_page,
                "page": page,
                "fields": "identifier,title,creator,licenseurl,rights,description"
            }
            url = "https://archive.org/advancedsearch.php?" + urlencode(params)
            try:
                j = requests.get(url, timeout=30).json()
            except Exception as e:
                print("[archive] error req", e); break
            docs = j.get("response",{}).get("docs",[])
            if not docs: break
            for d in docs:
                ident = d.get("identifier")
                if not ident: continue
                # metadata/files to enumerate MP4s
                meta_url = f"https://archive.org/metadata/{ident}"
                try:
                    meta = requests.get(meta_url, timeout=30).json()
                except Exception as e:
                    print("[archive] meta err", ident, e); continue
                files = meta.get("files",[])
                rights = (d.get("rights") or meta.get("metadata",{}).get("rights") or "").strip()
                licurl = (d.get("licenseurl") or meta.get("metadata",{}).get("licenseurl") or "").strip()
                lic_text = " / ".join([x for x in [rights, licurl] if x])
                # license filter (best-effort)
                keep = False
                if not license_allow: keep = True
                else:
                    test = (rights + " " + licurl).lower()
                    keep = any(t in test for t in license_allow)
                if not keep:
                    continue
                for f in files:
                    name = f.get("name","")
                    if not name.lower().endswith(".mp4"): 
                        continue
                    mp4_url = f"https://archive.org/download/{ident}/{name}"
                    page_url = f"https://archive.org/details/{ident}"
                    rows = {
                        "source":"archive",
                        "title": d.get("title",""),
                        "mp4_url": mp4_url,
                        "page_url": page_url,
                        "license": lic_text or "Unknown (check page)",
                        "duration": str(f.get("length","")),
                        "resolution": f"{f.get('width','')}x{f.get('height','')}",
                        "notes": ""
                    }
                    collected.append(rows)
                    if len(collected) >= target: 
                        break
                if len(collected) >= target:
                    break
            page += 1
    return collected

# -------- NASA SVS --------
def harvest_nasa_svs(cfg, target):
    collected = []
    q_terms = cfg.get("queries",["wildfire"])
    for q in q_terms:
        # search results are paged; we can scan first 10 pages
        for page in range(1, 11):
            url = f"https://svs.gsfc.nasa.gov/search/?keywords={quote_plus(q)}&page={page}"
            try:
                html = requests.get(url, timeout=30).text
            except Exception as e:
                print("[svs] error", e); break
            soup = BeautifulSoup(html, "html.parser")
            # find result links
            for a in soup.select("a[href^='https://svs.gsfc.nasa.gov/']"):
                href = a.get("href")
                if not re.search(r"/\d+/?$", href): 
                    continue
                # fetch page to scrape available movies
                try:
                    ph = requests.get(href, timeout=30).text
                except Exception:
                    continue
                ps = BeautifulSoup(ph, "html.parser")
                movs = ps.find_all("a", href=re.compile(r"\.mp4$"))
                title_tag = ps.find(["h1","title"])
                title = title_tag.get_text(strip=True) if title_tag else "NASA SVS"
                for m in movs:
                    mp4 = m.get("href")
                    if not mp4.startswith("http"):
                        # relative link
                        base = "/".join(href.split("/")[:3])
                        mp4 = base + mp4
                    collected.append({
                        "source":"nasa_svs",
                        "title": title,
                        "mp4_url": mp4,
                        "page_url": href,
                        "license":"Public Domain (NASA) — verify on page",
                        "duration":"",
                        "resolution":"",
                        "notes":""
                    })
                    if len(collected) >= target: 
                        return collected
    return collected

# -------- NOAA GOES pages --------
def harvest_noaa_goes(cfg, target):
    collected = []
    # Seed pages (add more as needed)
    seeds = [
        "https://www.goes-r.gov/multimedia/dataAndImageryVideosGoes-17.html",
        "https://www.goes-r.gov/multimedia/dataAndImageryVideosGoes-16.html"
    ]
    for url in seeds:
        try:
            html = requests.get(url, timeout=30).text
        except Exception as e:
            print("[noaa] error", e); continue
        soup = BeautifulSoup(html, "html.parser")
        for a in soup.find_all("a", href=True):
            if a.get_text(strip=True).lower().find("wildfire")>=0 or a.get_text(strip=True).lower().find("smoke")>=0 or "Download Video" in a.get_text():
                href = a["href"]
                if not href.lower().endswith(".mp4"): 
                    continue
                if not href.startswith("http"):
                    base = "/".join(url.split("/")[:3])
                    href = base + "/" + href.lstrip("/")
                collected.append({
                    "source":"noaa_goes",
                    "title": a.get_text(strip=True) or "NOAA GOES",
                    "mp4_url": href,
                    "page_url": url,
                    "license":"Public Domain (NOAA) — verify on page",
                    "duration":"",
                    "resolution":"",
                    "notes":""
                })
            if len(collected) >= target:
                return collected
    return collected

# -------- YouTube CC (watch URLs; for yt-dlp) --------
def harvest_youtube_cc(cfg, target):
    api_key = cfg.get("youtube",{}).get("api_key","").strip()
    if not api_key:
        print("[yt] no API key; skipping")
        return []
    collected = []
    per_query = int(cfg.get("youtube",{}).get("per_query",200))
    q_terms = cfg.get("queries",["wildfire"])
    for q in q_terms:
        page_token = ""
        fetched = 0
        while fetched < per_query:
            params = {
                "part":"snippet",
                "q": q,
                "type":"video",
                "videoLicense":"creativeCommon",
                "maxResults": 50,
                "pageToken": page_token
            }
            url = "https://www.googleapis.com/youtube/v3/search?" + urlencode(params) + f"&key={api_key}"
            try:
                j = requests.get(url, timeout=30).json()
            except Exception as e:
                print("[yt] req err", e); break
            for item in j.get("items",[]):
                vid = item["id"]["videoId"]
                title = item["snippet"]["title"]
                page_url = f"https://www.youtube.com/watch?v={vid}"
                collected.append({
                    "source":"youtube_cc",
                    "title": title,
                    "mp4_url": "",  # use yt-dlp to download later
                    "page_url": page_url,
                    "license":"CC BY (per YouTube API) — verify on page",
                    "duration":"",
                    "resolution":"",
                    "notes":"Use yt-dlp to download .mp4 for training if permitted."
                })
                fetched += 1
                if len(collected) >= target or fetched >= per_query:
                    break
            page_token = j.get("nextPageToken","")
            if not page_token: break
        if len(collected) >= target: break
    return collected

def main():
    try:
        import yaml
    except Exception:
        print("[i] Installing PyYAML ... run pip if needed")
    cfg = load_config()
    existing = read_existing()

    target = int(cfg.get("target_count", 10000)) - len(existing)
    print(f"[i] target additional rows: {target} (existing {len(existing)})")
    rows = []

    if target > 0 and cfg.get("sources",{}).get("archive",True):
        print("[*] Harvesting Internet Archive ...")
        rows += harvest_archive(cfg, target - len(rows))
    if target > 0 and cfg.get("sources",{}).get("nasa_svs",True):
        print("[*] Harvesting NASA SVS ...")
        rows += harvest_nasa_svs(cfg, target - len(rows))
    if target > 0 and cfg.get("sources",{}).get("noaa_goes",True):
        print("[*] Harvesting NOAA GOES ...")
        rows += harvest_noaa_goes(cfg, target - len(rows))
    if target > 0 and cfg.get("sources",{}).get("youtube_cc",False):
        print("[*] Harvesting YouTube Creative Commons ...")
        rows += harvest_youtube_cc(cfg, target - len(rows))

    rows = dedupe_rows(rows, existing)
    print(f"[i] New rows: {len(rows)}")
    if rows:
        write_rows(rows)
        print(f"[✓] Wrote {len(rows)} rows to {CSV_PATH}")
        print(f"[✓] M3U appended at {M3U_PATH}")
    else:
        print("[i] Nothing new to write")

if __name__ == "__main__":
    main()
