# Wildfire CC Video Harvester (up to 10,000 MP4 links)

This utility builds a CSV list of **.mp4 videos** of wildfires/smoke from open-license sources:

- **Internet Archive** (Public Domain & Creative Commons)
- **NASA SVS** (usually public domain)
- **NOAA GOES pages** (downloadable MP4s on feature pages)
- **YouTube (Creative Commons)** — optional: adds *watch URLs* (for download via yt-dlp).

> ⚖️ Always verify and respect the **license** and the site **Terms of Service**. This tool *filters* for PD/CC where fields exist, but you are responsible for final compliance.

## One‑click on Windows
1) Unzip anywhere (e.g., `C:\Users\YOU\wildfire-cc-harvester\`)
2) Double‑click **START Harvester.bat**
   - Creates `.venv`, installs requirements, runs `harvester\harvest.py`.
3) Results saved to `output\wildfire_videos.csv` and `output\wildfire_videos.m3u`.

You can re‑run START any time; it will append new finds (de‑duping).

## Config (optional)
Edit `harvester\config.yaml`:
- `target_count`: how many entries to collect (default 10000).
- `queries`: search terms in multiple languages.
- `sources`: enable/disable archive/nasa/noaa/youtube.
- `license_allow`: filters for license/rights fields.
- `youtube.api_key`: set your YouTube Data API key to include CC videos.

